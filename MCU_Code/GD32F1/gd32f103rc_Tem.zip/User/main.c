#include "gd32f10x.h"
#include "gd32f10x_libopt.h"
#include "systick.h"

int main(void)
{
	
	while(1)
	{

	}
}

