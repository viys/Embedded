#ifndef __BMP_H
#define __BMP_H
unsigned char BMP1[] =
{0
	
};

unsigned char BMP2[] =
{0
	
};

#endif


