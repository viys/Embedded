#include "stm32f4XX.h"
int main(void)
{
	/* 此处写入程序 */

	while(1);
}

