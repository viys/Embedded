#include <string.h>
#include <stdio.h>
#include "led.h"
#include "usart.h"
#include "key.h"
#include "LED.h"
#include "nvic.h"
#include "adc.h"
#include "systick.h"
#include "time6.h"
#include "time5_9.h"

int main(void )
{
#if 0
	LED_Init ();
	USART1_Init(84,115200,0);
//	Time6_inter_Init(8400,10000);
	
	while(1)
	{
		SysTick_ms(100);
		GPIOC ->ODR ^= 1 << 4;
//		Time6_delay (8400,500);
	}
#endif

#if 0
	ADC_Init();
	LED_Init ();
	USART1_Init(84,115200,0);
	u16 val = 0;
	float Vx =0;
	//Time6_Init();
	Time5_CH1_Init(168,0xffff,32768);
	Time9_CH1_Init(84,20000);
//	systick
	while(1)
	{
		SysTick_ms(500);
		GPIOC ->ODR ^= 1 << 4;
//		//Time6_delay (8400,10000);
//		val = ADC_GETD ();
//		Vx = (3.3 * val)/4096;
//		printf("��������%d\n",val);
//		printf("��ѹ��%.2f\n",Vx);
		
		if(width)
		{
			printf ("data = %d\r\n",width );
			
			
		}
	}
	
#endif
	
#if 1
	ADC_Init();
	LED_Init ();
	USART1_Init(84,115200,0);
	//Time6_Init();
	Time5_CH1_Init(168,0xffff,32768);
	Time9_CH1_Init(84,20000);
//	systick
	while(1)
	{
		SysTick_ms(500);
		printf ("data = %d\r\n",width );
		GPIOC ->ODR ^= 1 << 4;
		//Time6_delay (8400,10000);
		if(width)
		{
			printf ("data = %d\r\n",width );
			
			
		}
	}
#endif
}
