@brief  ：简介，简单介绍函数作用
@param  ：介绍函数参数
@return：函数返回类型说明
@exception NSException 可能抛出的异常.
@author zhangsan：  作者
@date 2011-07-27 22:30:00 ：时间
@version 1.0 ：版本  
@property ：属性介绍
