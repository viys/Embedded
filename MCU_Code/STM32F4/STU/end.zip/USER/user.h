#ifndef __USER_H
#define __USER_H

#define LDE1_Init LED_In((GPIO_TypeDef *) GPIOC_BASE,1)


#endif
