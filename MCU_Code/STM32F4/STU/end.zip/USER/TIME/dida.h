
#ifndef _SYSCLICK_H_
#define _SYSCLICK_K_
#include "stm32f4xx.h"                  
#define SYSCLK 21000
void Sysclick_us(u32 us);
void Sysclick_ms(u32 ms);

#endif
