#ifndef __METHOD_H
#define __METHOD_H

#include "stm32f4xx.h"
#include <stdio.h>

#define ArraySize(ARR) (sizeof(ARR) / sizeof(ARR[0]))

int sort_ave(int a[],int n);

#endif
