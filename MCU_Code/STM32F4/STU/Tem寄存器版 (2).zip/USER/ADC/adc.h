#ifndef __ADC_H
#define __ADC_H

#include "stm32f4xx.h"

void ADC_Init(void );
u16 ADC_GETD(void );
void ADC1_CH5_Init(void);

#endif
