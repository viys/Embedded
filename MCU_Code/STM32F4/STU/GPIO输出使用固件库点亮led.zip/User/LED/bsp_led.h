#ifndef _BSP_LED_H
#define _BSP_LED_H

#include "stm32f4xx.h"
/*LED���ú���*/
void LED_GPIO_Config1(void);
void LED_GPIO_Config2(void);
void LED_GPIO_Config3(void);
void LED_GPIO_Config4(void);
void PIN_GPIO_Config1(void);
void PIN_GPIO_Config2(void);
void PIN_GPIO_Config3(void);
#endif /* _BSP_LED_H */
